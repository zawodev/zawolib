python3 setup.py sdist bdist_wheel
twine upload dist/*

nowa wersja za kazdym razem